import { Logo } from "@/components/logo"
import { Input } from "@/components/ui/input"
import { MobileContainer } from "@/components/mobile-container"
import { CustomButton } from "@/components/custom-button"

export default function SignInPage() {
  return (
    <MobileContainer>
      <section className="flex flex-col gap-6 items-center justify-center px-6 py-10 flex-1">
        <Logo className="w-16 h-16" />
        <h1 className="text-2xl font-bold">Malang Hijau</h1>

        <div className="w-full space-y-4 mt-4">
          <Input
            placeholder="Username"
            className="w-full px-4 py-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-secondary"
          />
          <Input
            type="password"
            placeholder="Password"
            className="w-full px-4 py-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-secondary"
          />
          <CustomButton color="primary" href="/dashboard">
            Sign In
          </CustomButton>
        </div>
      </section>
    </MobileContainer>
  )
}
