"use client"

import { useRouter } from "next/navigation"
import { MobileContainer } from "@/components/mobile-container"

export default function HistoryPage() {
  const router = useRouter()

  return (
    <MobileContainer>
      <section className="flex flex-col flex-1 px-6 pt-8 pb-6">
        <button onClick={() => router.back()} className="text-sm text-primary mb-4">
          ← Back
        </button>
        <h2 className="text-xl font-bold mb-4">Contribution History</h2>
        <ul className="space-y-3 flex-1 overflow-y-auto">
          <li className="flex justify-between bg-stone-100 rounded-xl p-4">
            <span>2025-05-10</span>
            <span>3.2 kg</span>
            <span className="font-semibold text-primary">+64</span>
          </li>
          <li className="flex justify-between bg-stone-100 rounded-xl p-4">
            <span>2025-05-03</span>
            <span>2.1 kg</span>
            <span className="font-semibold text-primary">+42</span>
          </li>
          <li className="flex justify-between bg-stone-100 rounded-xl p-4">
            <span>2025-04-26</span>
            <span>4.0 kg</span>
            <span className="font-semibold text-primary">+80</span>
          </li>
        </ul>
      </section>
    </MobileContainer>
  )
}
