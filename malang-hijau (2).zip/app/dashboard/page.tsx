"use client"

import { useRouter } from "next/navigation"
import { MobileContainer } from "@/components/mobile-container"
import { CustomButton } from "@/components/custom-button"

export default function DashboardPage() {
  const router = useRouter()

  return (
    <MobileContainer>
      <section className="flex flex-col flex-1 px-6 pt-8 pb-6">
        <header className="flex justify-between items-center mb-6">
          <div>
            <p className="text-sm text-stone-500">Welcome back</p>
            <p className="text-lg font-semibold">User</p>
          </div>
          <span className="flex items-center gap-1 text-primary text-sm">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-5 h-5"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth="2"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m1 9a9 9 0 11-6-8.484" />
            </svg>
            Certified
          </span>
        </header>

        <section className="bg-green-100 rounded-2xl p-6 flex flex-col items-center text-center gap-2 mb-8">
          <p className="text-stone-600 text-sm">Your Green Points</p>
          <span className="font-mono text-4xl font-bold text-primary">1 240</span>
          <p className="text-xs text-stone-500">Your Code: XCV101</p>
        </section>

        <div className="flex-1 flex flex-col gap-4">
          <CustomButton color="primary" onClick={() => alert("Redeem coming soon")}>
            Tukarkan Poin
          </CustomButton>
          <CustomButton color="secondary" onClick={() => alert("Rewards coming soon")}>
            Cashback / Rewards
          </CustomButton>
          <CustomButton color="green" href="/history">
            Riwayat Kontribusi
          </CustomButton>
          <CustomButton color="green" href="/instructions">
            Sorting Instructions
          </CustomButton>
          <CustomButton color="red" href="/" className="mt-auto">
            Log Out
          </CustomButton>
        </div>
      </section>
    </MobileContainer>
  )
}
